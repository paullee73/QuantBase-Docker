# QuantBase
Platform for keeping track of stocks and receive moving averages.
